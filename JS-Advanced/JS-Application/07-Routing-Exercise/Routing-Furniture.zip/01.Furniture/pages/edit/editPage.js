import { editFurniture, getFurniture } from "../../services/furnitures.js";
import { editTemplate } from "./editTemplate.js";

async function editFormHandler(context, e) {
    e.preventDefault();
    let id = context.params.id;
    let form = new FormData(e.target);
    let make = form.get('make');
    console.log(make);
    let model = form.get('model');
    let year = form.get('year');
    let description = form.get('description');
    let price = form.get('price');
    let img = form.get('img');
    let material = form.get('material');

    let body = {
        make, model, year, description, price, img, material
    }

    let furnitureInfo = editFurniture(id, body);
    context.page.redirect(`/details/${id}`);
}

async function getView(context) {
    let id = context.params.id;
    let boundEditFormHandler = editFormHandler.bind(null, context);
    let form = {
        editFormHandler: boundEditFormHandler
    }
    let editDetails = await getFurniture(id);
    let viewHtml = editTemplate(editDetails, form);
    context.renderView(viewHtml);

}

let edit = {
    getView,
}

export default edit;